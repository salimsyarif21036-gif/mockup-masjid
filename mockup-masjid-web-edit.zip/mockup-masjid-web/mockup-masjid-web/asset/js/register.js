function isGmail(email) {
  const regex = /^[a-zA-Z0-9._%+-]+@gmail\.com$/;
  return regex.test(email);
}

document
  .getElementsByTagName("form")[0]
  .addEventListener("submit", function (e) {
    e.preventDefault();
    console.log("jalan");
    const email = document.getElementById("email");
    const password = document.getElementById("password");
    const confirm_password = document.getElementById("confirm_password");
    const nama = document.getElementById("nama");
    const noHp = document.getElementById("noHp");
    const lokasi = document.getElementById("lokasi");

    if (
      !email.value &&
      !password.value &&
      !confirm_password.value &&
      !nama.value &&
      !noHp.value &&
      !lokasi.value
    ) {
      alert("ada yang masih kosong");
      return;
    }

    if (!isGmail(email.value.toLowerCase())) {
      alert("Email Anda harus menggunakan domain @gmail.com");
      return;
    }

    window.location.href = "login.html";
  });

document.addEventListener("DOMContentLoaded", function () {
  const email = document.getElementById("email");
  const password = document.getElementById("password");

  if (!email.value && !password.value) {
    email.focus();
  }
});
