// Auto-update prayer times (simulation)
function updateCurrentPrayer() {
  const now = new Date();
  const currentHour = now.getHours();
  const currentMinute = now.getMinutes();
  const currentTime = currentHour * 60 + currentMinute;

  // Prayer times in minutes from midnight
  const prayerTimes = {
    subuh: 4 * 60 + 45,
    dzuhur: 12 * 60 + 15,
    ashar: 15 * 60 + 30,
    maghrib: 18 * 60 + 25,
    isya: 19 * 60 + 45,
  };

  // Remove current prayer class from all cards
  document.querySelectorAll(".prayer-card").forEach((card) => {
    card.classList.remove("current-prayer");
  });

  // Add current prayer class to appropriate card
  let currentPrayer = "Isya"; // default
  if (currentTime >= prayerTimes.subuh && currentTime < prayerTimes.dzuhur) {
    currentPrayer = "Subuh";
  } else if (
    currentTime >= prayerTimes.dzuhur &&
    currentTime < prayerTimes.ashar
  ) {
    currentPrayer = "Dzuhur";
  } else if (
    currentTime >= prayerTimes.ashar &&
    currentTime < prayerTimes.maghrib
  ) {
    currentPrayer = "Ashar";
  } else if (
    currentTime >= prayerTimes.maghrib &&
    currentTime < prayerTimes.isya
  ) {
    currentPrayer = "Maghrib";
  }

  document.querySelectorAll(".prayer-card").forEach((card) => {
    if (card.id === currentPrayer) {
      card.classList.add("current-prayer");
      const cardBody = card.querySelector(".card-body");

      // Cek apakah "Sedang Berlangsung" sudah ada
      const alreadyAdded = cardBody.querySelector("small");
      if (!alreadyAdded) {
        const statusText = document.createElement("small");
        statusText.textContent = "Sedang Berlangsung";
        statusText.classList.add("text-success");
        cardBody.appendChild(statusText);
      }
    }
  });
}

// Initialize
updateCurrentPrayer();

// Update every minute
setInterval(updateCurrentPrayer, 60000);

// Carousel auto-slide with custom interval
const carousel = new bootstrap.Carousel("#newsCarousel", {
  interval: 5000,
  wrap: true,
});

dataIframe = [
  {
    "masjid darusalam":
      '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.577763213657!2d107.03770047482877!3d-6.1872173938003145!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69891709f9b333%3A0xf8fafbb4eeb3fab8!2sMasjid%20Darussalam%20(Perum%20BOS)!5e0!3m2!1sid!2sid!4v1754447596339!5m2!1sid!2sid" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>',
  },
  {
    "masjid at-taubah":
      '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.116751306998!2d106.83304637482928!3d-6.248342793740059!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f3c8b4ccc6f3%3A0xe2ec9baa99310029!2sMASJID%20JAMI%20AT-TAUBAH!5e0!3m2!1sid!2sid!4v1754448760634!5m2!1sid!2sid" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>',
  },
  {
    "masjid al-muhajirin":
      '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.6995300270596!2d106.90479227482862!3d-6.170971693816351!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f5a829ee029f%3A0x4dcaa34afe350115!2sMasjid%20Al-Muhajirin!5e0!3m2!1sid!2sid!4v1754447871863!5m2!1sid!2sid" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>',
  },
];

document.addEventListener("DOMContentLoaded", function () {
  const items = document.querySelectorAll(".list-group-item");

  items.forEach((item) => {
    item.addEventListener("click", function (e) {
      e.preventDefault();

      const nama = this.querySelector("#namaTempat")
        .textContent.trim()
        .toLowerCase();

      dataIframe.forEach((data) => {
        const key = Object.keys(data)[0];
        if (key === nama) {
          document.getElementById("iframe").innerHTML = data[key];

          const iframe = document.querySelector("#iframe iframe");
          if (iframe) {
            iframe.classList.add("w-100", "h-100", "border", "border-black");
          }
        }
      });
    });
  });

  // 👉 Klik otomatis item pertama
  if (items.length > 0) {
    items[0].click(); // trigger click untuk yang pertama
  }
});
