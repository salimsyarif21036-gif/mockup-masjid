document.addEventListener("DOMContentLoaded", function () {
  const requiredInputs = document.querySelectorAll("input[required]");
  const requiredSelect = document.querySelectorAll("select[required]");

  requiredInputs.forEach((input) => {
    const label = document.querySelector(`label[for="${input.id}"]`);
    if (label && !label.innerHTML.includes("*")) {
      label.innerHTML += ' <span class="text-danger">*</span>';
    }
  });
  requiredSelect.forEach((input) => {
    const label = document.querySelector(`label[for="${input.id}"]`);
    if (label && !label.innerHTML.includes("*")) {
      label.innerHTML += ' <span class="text-danger">*</span>';
    }
  });
});
