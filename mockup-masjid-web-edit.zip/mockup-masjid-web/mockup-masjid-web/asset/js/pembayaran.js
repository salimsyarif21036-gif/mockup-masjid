// Handle payment card clicks
document.addEventListener("DOMContentLoaded", function () {
  const paymentCards = document.querySelectorAll(".payment-card");
  const modal = document.getElementById("paymentModal");
  const modalTitle = document.getElementById("modalTitle");
  const amountInput = document.getElementById("amount");
  const amountSection = document.getElementById("amountSection");

  paymentCards.forEach((card) => {
    card.addEventListener("click", function () {
      const title = this.getAttribute("data-title");
      const amount = this.getAttribute("data-amount");

      modalTitle.textContent = `Pembayaran ${title}`;

      if (amount === "custom") {
        amountSection.style.display = "block";
        amountInput.value = "";
        amountInput.placeholder = "Masukkan nominal yang diinginkan";
      } else {
        amountSection.style.display = "block";
        amountInput.value = amount;
        amountInput.readOnly = true;
      }
    });
  });

  document.getElementById("categoryFilter").addEventListener("change", function () {
    const selected = this.value;
    const allCards = document.querySelectorAll(".payment-card");

    allCards.forEach((card) => {
      if (selected === "all") {
        card.parentElement.style.display = "block";
      } else {
        if (card.classList.contains(selected)) {
          card.parentElement.style.display = "block";
        } else {
          card.parentElement.style.display = "none";
        }
      }
    });
  });

  // format slug name
  function formatName(slug) {
    return slug
      .split("-") // pisahkan dengan tanda -
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1)) // kapital tiap kata
      .join(" "); // gabung dengan spasi
  }

  // handle select masjdi-option dan noRek
  const masjidOption = document.getElementById("masjid-option");
  const noRek = document.getElementById("noRek");
  masjidOption.addEventListener("change", function () {
    if (masjidOption.value === "masjid-darussalam") {
      noRek.value = `Mandiri ${formatName(masjidOption.value)} - 1234567890`;
    } else if (masjidOption.value === "masjid-alhuda") {
      noRek.value = `Mandiri ${formatName(masjidOption.value)} - 0987654321`;
    } else if (masjidOption.value === "masjid-almuhajirin") {
      noRek.value = `Mandiri ${formatName(masjidOption.value)} - 9876543210`;
    }
  });
});

function processPayment() {
  const amount = document.getElementById("amount").value;
  const payerName = document.getElementById("payerName").value;
  const noRek = document.getElementById("noRek").value;
  const masjidOption = document.getElementById("masjid-option").value;
  const filePayment = document.getElementById("filePayment")?.files[0];

  if (!amount || !payerName) {
    alert("Mohon lengkapi nominal dan nama pembayar");
    return;
  }

  if (!noRek || !masjidOption) {
    alert("Mohon lengkapi nomor rekening dan masjid");
    return;
  }

  // pengeceknn file
  if (!filePayment) {
    alert("File belum dipilih.");
    return;
  } else {
    const allowedTypes = ["image/png", "image/jpg", "image/jpeg"];
    const validExtensions = [".png", ".jpg", ".jpeg"];
    const fileType = filePayment.type;
    const fileName = filePayment.name.toLowerCase();

    const isValidExt = validExtensions.some((ext) => fileName.endsWith(ext));

    if (!allowedTypes.includes(fileType) || !isValidExt) {
      alert("File harus berupa gambar PNG atau JPG.");
      return;
    }
  }

  if (parseInt(amount) < 1000) {
    alert("Nominal minimal adalah Rp 1.000");
    return;
  }

  // Simulate payment processing
  const modal = bootstrap.Modal.getInstance(
    document.getElementById("paymentModal")
  );
  modal.hide();

  // Show success message
  setTimeout(() => {
    alert(
      `Terima kasih ${payerName}! Pembayaran sebesar Rp ${parseInt(
        amount
      ).toLocaleString(
        "id-ID"
      )} berhasil diproses. Semoga menjadi amal jariyah yang berkah.`
    );

    // Reset form
    document.getElementById("paymentForm").reset();
  }, 500);
}

// Format currency input
document.getElementById("amount").addEventListener("input", function (e) {
  if (this.readOnly) return;

  let value = this.value.replace(/\D/g, "");
  this.value = value;
});
