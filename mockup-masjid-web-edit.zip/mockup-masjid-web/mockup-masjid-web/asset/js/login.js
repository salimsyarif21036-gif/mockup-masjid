function isGmail(email) {
  const regex = /^[a-zA-Z0-9._%+-]+@gmail\.com$/;
  return regex.test(email);
}

document
  .getElementsByTagName("form")[0]
  .addEventListener("submit", function (e) {
    e.preventDefault();
    console.log("jalan");
    const email = document.getElementById("email");
    const password = document.getElementById("password");

    if (!email.value && !password.value) {
      email.focus();
      return;
    }

    if (!isGmail(email.value.toLowerCase())) {
      alert("Email Anda harus menggunakan domain @gmail.com");
      return;
    }

    window.location.href = "dashboard.html";
  });

document.addEventListener("DOMContentLoaded", function () {
  const email = document.getElementById("email");
  const password = document.getElementById("password");

  if (!email.value && !password.value) {
    email.focus();
  }
});
