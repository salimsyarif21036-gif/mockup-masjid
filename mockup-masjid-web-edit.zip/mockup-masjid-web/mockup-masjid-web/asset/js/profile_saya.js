// Toggle password visibility
function togglePassword(fieldId) {
  const field = document.getElementById(fieldId);
  const icon = document.getElementById(fieldId + "Icon");

  if (field.type === "password") {
    field.type = "text";
    icon.classList.remove("fa-eye");
    icon.classList.add("fa-eye-slash");
  } else {
    field.type = "password";
    icon.classList.remove("fa-eye-slash");
    icon.classList.add("fa-eye");
  }
}

// Password strength checker
function checkPasswordStrength(password) {
  let strength = 0;
  let feedback = [];

  if (password.length >= 8) strength += 1;
  else feedback.push("minimal 8 karakter");

  if (/[a-z]/.test(password)) strength += 1;
  else feedback.push("huruf kecil");

  if (/[A-Z]/.test(password)) strength += 1;
  else feedback.push("huruf besar");

  if (/[0-9]/.test(password)) strength += 1;
  else feedback.push("angka");

  if (/[^A-Za-z0-9]/.test(password)) strength += 1;
  else feedback.push("simbol");

  return { strength, feedback };
}

// Update password strength indicator
document.getElementById("newPassword").addEventListener("input", function () {
  const password = this.value;
  const { strength, feedback } = checkPasswordStrength(password);
  const strengthBar = document.getElementById("strengthBar");
  const strengthText = document.getElementById("strengthText");

  // Remove all strength classes
  strengthBar.className = "password-strength-bar";

  if (password === "") {
    strengthText.textContent = "Masukkan password baru";
    strengthText.className = "text-muted";
    return;
  }

  switch (strength) {
    case 0:
    case 1:
      strengthBar.classList.add("strength-weak");
      strengthText.textContent =
        "Password lemah - perlu: " + feedback.join(", ");
      strengthText.className = "text-danger";
      break;
    case 2:
    case 3:
      strengthBar.classList.add("strength-fair");
      strengthText.textContent =
        "Password cukup - perlu: " + feedback.join(", ");
      strengthText.className = "text-warning";
      break;
    case 4:
      strengthBar.classList.add("strength-good");
      strengthText.textContent = "Password baik";
      strengthText.className = "text-info";
      break;
    case 5:
      strengthBar.classList.add("strength-strong");
      strengthText.textContent = "Password kuat";
      strengthText.className = "text-success";
      break;
  }
});

// Check password confirmation
document
  .getElementById("confirmPassword")
  .addEventListener("input", function () {
    const newPassword = document.getElementById("newPassword").value;
    const confirmPassword = this.value;
    const matchDiv = document.getElementById("passwordMatch");

    if (confirmPassword === "") {
      matchDiv.innerHTML = "";
      return;
    }

    if (newPassword === confirmPassword) {
      matchDiv.innerHTML =
        '<small class="text-success"><i class="fas fa-check me-1"></i>Password cocok</small>';
    } else {
      matchDiv.innerHTML =
        '<small class="text-danger"><i class="fas fa-times me-1"></i>Password tidak cocok</small>';
    }
  });

// Show alert message
function showAlert(message, type = "success") {
  const alertContainer = document.getElementById("alertContainer");
  const alertDiv = document.createElement("div");
  alertDiv.className = `alert alert-${type} alert-custom alert-dismissible fade show`;
  alertDiv.innerHTML = `
                <i class="fas fa-${
                  type === "success" ? "check-circle" : "exclamation-circle"
                } me-2"></i>
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            `;
  alertContainer.appendChild(alertDiv);

  // Auto remove after 5 seconds
  setTimeout(() => {
    if (alertDiv.parentNode) {
      alertDiv.remove();
    }
  }, 5000);
}

// Handle profile form submission
document.getElementById("profileForm").addEventListener("submit", function (e) {
  e.preventDefault();

  // Simulate API call
  setTimeout(() => {
    showAlert("Informasi profil berhasil diperbarui!", "success");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, 1000);
});

// Handle password form submission
document
  .getElementById("passwordForm")
  .addEventListener("submit", function (e) {
    e.preventDefault();

    const currentPassword = document.getElementById("currentPassword").value;
    const newPassword = document.getElementById("newPassword").value;
    const confirmPassword = document.getElementById("confirmPassword").value;

    // Validation
    if (newPassword !== confirmPassword) {
      showAlert("Konfirmasi password tidak cocok!", "danger");
      return;
    }

    if (newPassword.length < 8) {
      showAlert("Password baru minimal 8 karakter!", "danger");
      return;
    }

    if (currentPassword === newPassword) {
      showAlert("Password baru harus berbeda dari password lama!", "danger");
      return;
    }

    // Simulate API call
    setTimeout(() => {
      showAlert("Password berhasil diubah!", "success");
      this.reset();
      document.getElementById("strengthBar").className =
        "password-strength-bar";
      document.getElementById("strengthText").textContent =
        "Masukkan password baru";
      document.getElementById("strengthText").className = "text-muted";
      document.getElementById("passwordMatch").innerHTML = "";
      window.scrollTo({ top: 0, behavior: "smooth" });
    }, 1000);
  });

// Reset profile form
function resetProfileForm() {
  document.getElementById("fullName").value = "Ahmad Ridwan";
  document.getElementById("email").value = "ahmad.ridwan@email.com";
  document.getElementById("phone").value = "08123456789";
  document.getElementById("mosque").value = "al-hidayah";
  document.getElementById("address").value =
    "Jl. Raya Bekasi No. 456, RT 02/RW 05, Bekasi Utara, Bekasi, Jawa Barat 17124";
}
