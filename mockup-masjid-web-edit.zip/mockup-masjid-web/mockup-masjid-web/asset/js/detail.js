// Auto-update prayer times (simulation)
function updateCurrentPrayer() {
  const now = new Date();
  const currentHour = now.getHours();
  const currentMinute = now.getMinutes();
  const currentTime = currentHour * 60 + currentMinute;

  // Prayer times in minutes from midnight
  const prayerTimes = {
    subuh: 4 * 60 + 45,
    dzuhur: 12 * 60 + 15,
    ashar: 15 * 60 + 30,
    maghrib: 18 * 60 + 25,
    isya: 19 * 60 + 45,
  };

  // Remove current prayer class from all cards
  document.querySelectorAll(".prayer-card").forEach((card) => {
    card.classList.remove("current-prayer");
  });

  // Add current prayer class to appropriate card
  let currentPrayer = "Isya"; // default
  if (currentTime >= prayerTimes.subuh && currentTime < prayerTimes.dzuhur) {
    currentPrayer = "Subuh";
  } else if (
    currentTime >= prayerTimes.dzuhur &&
    currentTime < prayerTimes.ashar
  ) {
    currentPrayer = "Dzuhur";
  } else if (
    currentTime >= prayerTimes.ashar &&
    currentTime < prayerTimes.maghrib
  ) {
    currentPrayer = "Ashar";
  } else if (
    currentTime >= prayerTimes.maghrib &&
    currentTime < prayerTimes.isya
  ) {
    currentPrayer = "Maghrib";
  }

  document.querySelectorAll(".prayer-card").forEach((card) => {
    if (card.id === currentPrayer) {
      card.classList.add("current-prayer");
      const cardBody = card.querySelector(".card-body");

      // Cek apakah "Sedang Berlangsung" sudah ada
      const alreadyAdded = cardBody.querySelector("small");
      if (!alreadyAdded) {
        const statusText = document.createElement("small");
        statusText.textContent = "Sedang Berlangsung";
        statusText.classList.add("text-primary");
        cardBody.appendChild(statusText);
      }
    }
  });
}

// Initialize
updateCurrentPrayer();

// Update every minute
setInterval(updateCurrentPrayer, 60000);

// Animasi counter
function animateCounter(elementId, finalValue, duration = 2000) {
  const element = document.getElementById(elementId);
  if (!element) return;

  const startValue = 0;
  const increment = finalValue / (duration / 16);
  let currentValue = startValue;

  const timer = setInterval(() => {
    currentValue += increment;
    if (currentValue >= finalValue) {
      currentValue = finalValue;
      clearInterval(timer);
    }

    if (elementId.includes("Amount")) {
      element.textContent =
        "Rp " + Math.floor(currentValue).toLocaleString("id-ID");
    } else {
      element.textContent = Math.floor(currentValue).toLocaleString("id-ID");
    }
  }, 16);
}

// Animasi progress bar
function animateProgressBar(elementId, percentage, delay = 0) {
  setTimeout(() => {
    const element = document.getElementById(elementId);
    if (element) {
      element.style.width = "0%";
      setTimeout(() => {
        element.style.width = percentage + "%";
      }, 100);
    }
  }, delay);
}

// Fungsi untuk menampilkan lebih banyak kegiatan
function showMoreActivities() {
  const additionalActivities = `
                <div class="activity-card card">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-md-8">
                                <h5><i class="fas fa-graduation-cap text-primary me-2"></i>Kelas Bahasa Arab</h5>
                                <p class="mb-1">Setiap Sabtu, 08:00 - 10:00 WIB</p>
                                <p class="text-muted mb-0">3 tingkat: Pemula, Menengah, Lanjut</p>
                            </div>
                            <div class="col-md-4 text-end">
                                <span class="badge bg-info fs-6">45 Peserta</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="activity-card card">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-md-8">
                                <h5><i class="fas fa-heart text-primary me-2"></i>Pelayanan Kesehatan Gratis</h5>
                                <p class="mb-1">Setiap Minggu ke-2 & ke-4, 08:00 - 12:00 WIB</p>
                                <p class="text-muted mb-0">Bekerjasama dengan RS Islam Jakarta</p>
                            </div>
                            <div class="col-md-4 text-end">
                                <span class="badge bg-danger fs-6">50+ Pasien</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="activity-card card">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-md-8">
                                <h5><i class="fas fa-laptop text-primary me-2"></i>Kursus Komputer Gratis</h5>
                                <p class="mb-1">Setiap Sabtu, 13:00 - 15:00 WIB</p>
                                <p class="text-muted mb-0">Untuk remaja masjid dan masyarakat</p>
                            </div>
                            <div class="col-md-4 text-end">
                                <span class="badge bg-info fs-6">25 Peserta</span>
                            </div>
                        </div>
                    </div>
                </div>
            `;

  const button = event.target;

  const cardBody = button.closest(".card-body");
  console.log(cardBody);
  if (cardBody) {
    cardBody.insertAdjacentHTML("beforeend", additionalActivities);
  } else {
    console.error("card-body tidak ditemukan sebagai parent dari button.");
  }
  button.parentNode.remove();
}

// Fungsi untuk melihat laporan lengkap
function viewDetailedReport() {
  alert("Laporan keuangan lengkap akan segera dibuka dalam tab baru.");
}

// Update waktu real-time
function updateCurrentTime() {
  const now = new Date();
  const timeString = now.toLocaleTimeString("id-ID");

  // Update di header jika ada element untuk waktu saat ini
  const timeElement = document.getElementById("currentTime");
  if (timeElement) {
    timeElement.textContent = timeString;
  }
}

// Inisialisasi saat halaman dimuat
document.addEventListener("DOMContentLoaded", function () {
  // Animasi counter dengan delay
  setTimeout(() => animateCounter("totalJamaah", 2450, 2500), 300);
  setTimeout(() => animateCounter("jamaahAktif", 1890, 2000), 600);
  setTimeout(() => animateCounter("jamaahBaru", 156, 1500), 900);

  // Animasi progress bar
  animateProgressBar("infaqProgress", 82, 500);
  animateProgressBar("qurbanProgress", 95, 700);
  animateProgressBar("zakatProgress", 78, 900);

  // Update waktu setiap detik
  updateCurrentTime();
  setInterval(updateCurrentTime, 1000);

  // Smooth scroll untuk link internal
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute("href"));
      if (target) {
        target.scrollIntoView({
          behavior: "smooth",
          block: "start",
        });
      }
    });
  });

  // Intersection Observer untuk animasi fade-in
  const observerOptions = {
    threshold: 0.1,
    rootMargin: "0px 0px -50px 0px",
  };

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = "1";
        entry.target.style.transform = "translateY(0)";

        // Hapus style setelah animasi selesai
        if (entry.target.classList.contains("activity-card")) {
          setTimeout(() => {
            entry.target.style.cssText = "";
          }, 600); // Match dengan durasi transisi (0.6s)
        }
      }
    });
  }, observerOptions);

  // Terapkan observer ke semua card
  document.querySelectorAll(".card").forEach((card) => {
    card.style.opacity = "0";
    card.style.transform = "translateY(30px)";
    card.style.transition = "all 0.6s ease";
    observer.observe(card);
  });
});

// Fungsi untuk menampilkan notifikasi
function showNotification(message, type = "success") {
  const notification = document.createElement("div");
  notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
  notification.style.cssText =
    "top: 20px; right: 20px; z-index: 9999; min-width: 300px;";
  notification.innerHTML = `
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            `;

  document.body.appendChild(notification);

  setTimeout(() => {
    if (notification.parentNode) {
      notification.remove();
    }
  }, 5000);
}

// Event listener untuk tombol copy rekening
document.addEventListener("click", function (e) {
  if (e.target.tagName === "CODE") {
    navigator.clipboard
      .writeText(e.target.textContent)
      .then(() => {
        showNotification("Nomor rekening berhasil disalin!", "success");
      })
      .catch(() => {
        showNotification("Gagal menyalin nomor rekening", "danger");
      });
  }
});

// Fungsi untuk mengecek jadwal shalat dan memberikan notifikasi
function checkPrayerTime() {
  const now = new Date();
  const currentTime = now.getHours() * 60 + now.getMinutes();

  const prayerTimes = {
    Subuh: 4 * 60 + 45,
    Dzuhur: 12 * 60 + 15,
    Ashar: 15 * 60 + 30,
    Maghrib: 18 * 60 + 10,
    Isya: 19 * 60 + 25,
  };

  Object.entries(prayerTimes).forEach(([prayer, time]) => {
    if (Math.abs(currentTime - time) < 5) {
      // 5 menit sebelum adzan
      showNotification(
        `⏰ Waktu ${prayer} akan segera tiba (${Math.floor(time / 60)}:${(
          time % 60
        )
          .toString()
          .padStart(2, "0")})`,
        "warning"
      );
    }
  });
}

// Cek jadwal shalat setiap 5 menit
setInterval(checkPrayerTime, 5 * 60 * 1000);
